
package game1;
import java.io.*;
import java.net.*;
import javax.swing.*;

public class snack2 extends javax.swing.JFrame {
 private static final String HOST = "localhost";
    private static final int PORT = 6666;
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    
    private int player1Pos = 0;
    private int player2Pos = 0;
    private boolean myTurn = false;
    private java.util.List<javax.swing.JLabel> cells = new java.util.ArrayList<>();
    
    public snack2() {
        initComponents();
        setupBoard();
        connectToServer();
    }

    private void setupBoard() {
        jPanel1.setLayout(new java.awt.GridLayout(4, 5));
        
        for (int i = 20; i >= 1; i--) {
            javax.swing.JLabel cell = new javax.swing.JLabel(String.valueOf(i), javax.swing.SwingConstants.CENTER);
            cell.setOpaque(true);
            cell.setPreferredSize(new java.awt.Dimension(80, 80));
            cell.setBackground(java.awt.Color.WHITE);
            cell.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.BLACK));

            if (i == 16 || i == 19 || i == 5) {
                cell.setBackground(java.awt.Color.RED);
            }
            if (i == 11 || i == 17) {
                cell.setBackground(java.awt.Color.BLUE);
            }
            cells.add(0, cell);
            jPanel1.add(cell);
        }
    }

    private void connectToServer() {
        new Thread(() -> {
            try {
                socket = new Socket(HOST, PORT);
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                
                String firstMsg = in.readLine();
                if ("CONNECTED".equals(firstMsg)) {
                    SwingUtilities.invokeLater(() -> {
                        updateStatus("Connected! Waiting for Player 1...");
                        jButton2.setEnabled(false);
                    });
                }
                
                while (true) {
                    String received = in.readLine();
                    if (received == null) continue;
                    
                    if (received.startsWith("MOVE:")) {
                        handleOpponentMove(received.substring(5));
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void handleOpponentMove(String moveData) {
        String[] parts = moveData.split(",");
        int newPos = Integer.parseInt(parts[0]);
        boolean won = Boolean.parseBoolean(parts[1]);
        
        SwingUtilities.invokeLater(() -> {
            // Clear old position
            if (player1Pos > 0) {
                resetCellColor(player1Pos);
            }
            
            player1Pos = newPos;
            cells.get(player1Pos - 1).setBackground(java.awt.Color.GREEN);
            
            if (won) {
                JOptionPane.showMessageDialog(this, "Player 1 won the game!");
                System.exit(0);
            }
            
            myTurn = true;
            jButton2.setEnabled(true);
            updateStatus("Your turn! Click Roll");
        });
    }

private void resetCellColor(int pos) {
    int index = pos - 1;
    
    // Don't check for player positions here - we're trying to reset the color
    if (index == 15 || index == 18 || index == 4) { // Snake positions
        cells.get(index).setBackground(java.awt.Color.RED);
    } else if (index == 10 || index == 16) { // Ladder positions
        cells.get(index).setBackground(java.awt.Color.BLUE);
    } else {
        cells.get(index).setBackground(java.awt.Color.WHITE);
    }
}
    private void updateStatus(String message) {
        jTextField1.setText(message);
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 102));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 735, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 396, Short.MAX_VALUE)
        );

        jButton2.setBackground(new java.awt.Color(204, 204, 255));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setText("Roll");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTextField1.setBackground(new java.awt.Color(255, 255, 204));

        jLabel1.setText("Yellow Color");

        jButton1.setBackground(new java.awt.Color(51, 204, 255));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/game1/back22.png"))); // NOI18N
        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(127, 127, 127)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addGap(36, 36, 36))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel1)
                                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      if (!myTurn) return;
        
        int dice = (int)(Math.random() * 3) + 1;
        jButton2.setText("Rolled: " + dice);
        
        // Clear old position
        if (player2Pos > 0) {
            resetCellColor(player2Pos);
        }
        
        // Move player
        player2Pos += dice;
        if (player2Pos > 20) player2Pos = 20;
        
        // Check snakes
        if (player2Pos == 16 || player2Pos == 19 || player2Pos == 5) {
            JOptionPane.showMessageDialog(this, "You got bitten by a snake at " + player2Pos);
            player2Pos = 1;
        }
        
        // Check ladders
        if (player2Pos == 11) {
            JOptionPane.showMessageDialog(this, "You climbed a ladder at " + player2Pos);
            player2Pos = 17;
        }
        
        // Update display
        cells.get(player2Pos - 1).setBackground(java.awt.Color.YELLOW);
        
        // Check win condition
        boolean won = (player2Pos == 20);
        if (won) {
            JOptionPane.showMessageDialog(this, "🎉 You won the game!");
            out.println("MOVE:" + player2Pos + ",true");
            System.exit(0);
        }
        
        // Send move to opponent
        out.println("MOVE:" + player2Pos + ",false");
        myTurn = false;
        jButton2.setEnabled(false);
        updateStatus("Waiting for Player 1...");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

setVisible(false);
// new Home().setVisible(true);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

  
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new snack2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
