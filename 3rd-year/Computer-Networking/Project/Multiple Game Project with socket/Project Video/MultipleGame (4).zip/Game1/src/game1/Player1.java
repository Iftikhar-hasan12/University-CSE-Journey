
package game1;
import java.io.*;
import java.net.*;
import javax.swing.*;



public class Player1 extends javax.swing.JFrame {
     // Network components
    private static final int PORT = 6666;
    private ServerSocket serverSocket;
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    
  // Game state
    private String player1Choice = "";
    private String player2Choice = "";
    private boolean player1Turn = true;
    private int roundsToPlay;
    private int roundsPlayed = 0;
    private int player1Score = 0;
    private int player2Score = 0;
    private String p1="";
    private String p2 ="";
    
    
      public Player1(int rounds) {
        this.roundsToPlay = rounds;
       
        initComponents();
        jButton1.setText("Rock");
        jButton2.setText("Paper");
        jButton3.setText("Scissors");
        updateDisplay("Waiting for Player 2 to connect...\nRounds to play: " + roundsToPlay);
        startServer();
    }


      
      
 private void updateDisplay(String message) {
        jTextArea1.setText(message);
        // MODIFICATION: Update scoreboard
        scorearea.setText("Player 1: " + player1Score + "\nPlayer 2: " + player2Score + 
                         "\nRound: " + (roundsPlayed+1) + "/" + roundsToPlay);
    }
 
 
 
 
 private void startServer() {
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(PORT);
                socket = serverSocket.accept();
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                
                // MODIFICATION: Send initial round count to Player2
                out.println("ROUNDS:" + roundsToPlay);
                updateDisplay("Player 2 connected! Make your choice.");
                out.println("TURN:1");
                
                while (roundsPlayed < roundsToPlay) {
                    String received = in.readLine();
                    if (received != null) {
                        if (received.startsWith("PLAYER2_CHOICE:")) {
                            player2Choice = received.substring(15);
                            if (!player1Choice.isEmpty()) {
                                determineWinner();
                            }
                        }
                    }
                }
                // MODIFICATION: Game over handling
                endGame();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void determineWinner() {
        String result;
        
        if (player1Choice.equals(player2Choice)) {
            result = "Round " + (roundsPlayed+1) + ": Tie!";
        } else if ((player1Choice.equals("Rock") && player2Choice.equals("Scissors")) ||
                  (player1Choice.equals("Paper") && player2Choice.equals("Rock")) ||
                  (player1Choice.equals("Scissors") && player2Choice.equals("Paper"))) {
            result = "Round " + (roundsPlayed+1) + ": Player 1 wins!";
            player1Score++;
        } else {
            result = "Round " + (roundsPlayed+1) + ": Player 2 wins!";
            player2Score++;
        }
        
        String message = "Round " + (roundsPlayed+1) + "||" +
                        "Player 1: " + player1Choice + "||" +
                        "Player 2: " + player2Choice + "||" +
                        result;
        
        updateDisplay(message.replace("||", "\n"));
        out.println("RESULT:" + message);
        
        // Reset for next round
        player1Choice = "";
        player2Choice = "";
        roundsPlayed++;
        
        if (roundsPlayed < roundsToPlay) {
            player1Turn = true;
            out.println("TURN:1");
        } else {
            endGame();
        }
    }

    // MODIFICATION: Added game over handling
    private void endGame() {
    // Determine final messages for each player
    String player1Message, player2Message;
    
    if (player1Score > player2Score) {
        player1Message = "CONGRATS YOU WON WITH SCORE " + player1Score + "-" + player2Score;
        player2Message = "YOU LOSE WITH SCORE " + player2Score + "-" + player1Score + ", BETTER LUCK NEXT TIME";
    } else if (player2Score > player1Score) {
        player1Message = "YOU LOSE WITH SCORE " + player1Score + "-" + player2Score + ", BETTER LUCK NEXT TIME";
        player2Message = "CONGRATS YOU WON WITH SCORE " + player2Score + "-" + player1Score;
    } else {
        player1Message = player2Message = "IT'S A TIE! FINAL SCORE " + player1Score + "-" + player2Score;
    }
    
    // Show different messages to each player
    updateDisplay(player1Message);
    out.println("GAMEOVER:" + player2Message); // Send specific message to Player2
    
    // Disable buttons
    jButton1.setEnabled(false);
    jButton2.setEnabled(false);
    jButton3.setEnabled(false);
    
    try {
        socket.close();
        serverSocket.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        name1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        scorearea = new javax.swing.JTextArea();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 102, 153));

        jTextArea1.setBackground(new java.awt.Color(255, 255, 204));
        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setText("Rock");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setText("Paper");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton3.setText("Scissor");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        name1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        name1.setText("Player 1");

        scorearea.setBackground(new java.awt.Color(255, 255, 204));
        scorearea.setColumns(20);
        scorearea.setRows(5);
        jScrollPane2.setViewportView(scorearea);

        jButton4.setBackground(new java.awt.Color(102, 204, 255));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton4.setText("Chat");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(153, 255, 153));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton5.setText("Back");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton4)
                        .addGap(26, 26, 26)
                        .addComponent(jButton5)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(127, 127, 127)
                        .addComponent(jButton2)
                        .addGap(157, 157, 157)
                        .addComponent(jButton3)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(151, 151, 151)
                                .addComponent(name1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 246, Short.MAX_VALUE)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(name1)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton1)
                    .addComponent(jButton3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addGap(15, 15, 15))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
 if (player1Turn) {
            player1Choice = "Rock";
            updateDisplay("You chose Rock. Waiting for Player 2...");
            player1Turn = false;
            out.println("PLAYER1_CHOICE:Rock");
            out.println("TURN:2"); // Notify Player2 it's their turn
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    if (player1Turn) {
            player1Choice = "Paper";
            updateDisplay("You chose Paper. Waiting for Player 2...");
            player1Turn = false;
            out.println("PLAYER1_CHOICE:Paper");
            out.println("TURN:2");
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      if (player1Turn) {
            player1Choice = "Scissors";
            updateDisplay("You chose Scissors. Waiting for Player 2...");
            player1Turn = false;
            out.println("PLAYER1_CHOICE:Scissors");
            out.println("TURN:2");
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
         if (player1Turn) {
        javax.swing.SwingUtilities.invokeLater(() -> {
        //setVisible(false);
        new Client2().setVisible(true);
    });
    
    // Start Client after short delay
    new java.util.Timer().schedule(
        new java.util.TimerTask() {
            @Override
            public void run() {
                javax.swing.SwingUtilities.invokeLater(() -> {
                    setVisible(false);
                    new Client1().setVisible(true);
                });
            }
        },
        500 // 0.5 second delay
    );
         }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

setVisible(false);
 new Home().setVisible(true);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
    java.awt.EventQueue.invokeLater(() -> {
            new Player1(1).setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel name1;
    private javax.swing.JTextArea scorearea;
    // End of variables declaration//GEN-END:variables
}
