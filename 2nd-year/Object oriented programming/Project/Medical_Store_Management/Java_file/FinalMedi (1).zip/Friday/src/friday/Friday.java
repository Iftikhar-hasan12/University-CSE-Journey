
package friday;


public class Friday {
    public static void main(String[] args) {
      
        
        
    }
    
}
