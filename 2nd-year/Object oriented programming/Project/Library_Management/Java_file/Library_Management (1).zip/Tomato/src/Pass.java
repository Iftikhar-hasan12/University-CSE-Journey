
import Project.ConnectionProvider;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;


public class Pass extends javax.swing.JFrame {
int id;
   
    public Pass() {
        initComponents();
    }
      public Pass(int a) {
        initComponents();
        id=a;
    }
      public int getId()
      {
          return id;
      }
    
//     public UserInterface(int a) {
//        initComponents();
//        setExtendedState(MAXIMIZED_BOTH);
//        id =a;
//     }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jRadioButton1 = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();

        jRadioButton1.setText("jRadioButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(325, 125));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("Current Password");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(55, 88, 135, -1));

        jLabel2.setText("New Password");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(55, 116, 135, -1));

        jLabel3.setText("Re-Write Password");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(55, 159, 135, -1));
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(196, 88, 117, -1));
        getContentPane().add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(196, 122, 117, -1));
        getContentPane().add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(196, 156, 117, -1));

        jButton1.setText("Change");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(241, 228, -1, -1));

        jButton2.setText("Cancel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 228, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setText("Password Change ");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(109, 27, -1, -1));

        jPanel1.setBackground(new java.awt.Color(87, 166, 161));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 410, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 310, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 410, 310));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        setVisible(false);
        //  new Mainpage().setVisible(true);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        if (jTextField1.getText().isEmpty() || jTextField2.getText().isEmpty() || jTextField3.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Fill the blank");
        } else {

            try {
                String Agerpass = jTextField1.getText();

                String Newpass = jTextField2.getText();
                String abarNewpass = jTextField3.getText();

                int ap = Integer.parseInt(Agerpass);
                int np = Integer.parseInt(Newpass);
                int anp = Integer.parseInt(abarNewpass);
                if (np != anp) {
                    JOptionPane.showMessageDialog(null, "Must Enter Same Pass");

                } else {

                    Connection con = ConnectionProvider.getCon();

                    int userid = id;

                    Statement st = con.createStatement();
                    ResultSet rs = st.executeQuery("SELECT UserID FROM security WHERE UserID ='" + userid + "' AND PASSWORD= '" + ap + "'");
                    if (rs.next()) {
                        // User exists, update the password
                        int updateCount = st.executeUpdate("UPDATE security SET PASSWORD = '" + np + "' WHERE UserID = '" + userid + "' AND PASSWORD = '" + ap + "'");
                        if (updateCount > 0) {
                           // System.out.println("Password updated successfully.");
                             JOptionPane.showMessageDialog(null, "Successfully updated password." );
                        } else {
                          //  System.out.println("Failed to update password.");
                             JOptionPane.showMessageDialog(null, "Failed to update password." );
                        }
                    } else {
                        //System.out.println("Invalid user ID or password.");
                        JOptionPane.showMessageDialog(null, "Invalid user ID or password." );
                    }

                }

            } catch (Exception e) {

                JOptionPane.showMessageDialog(null, "Error:" + e.getMessage());
            }

            // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed
    }

   
    public static void main(String args[]) {
     
 final int userId = 22312;
  
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Pass(userId).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    // End of variables declaration//GEN-END:variables
}
