
import Project.ConnectionProvider;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class IssueBook extends javax.swing.JFrame {

    public IssueBook() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(325, 125));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Issue Book");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(164, 24, 130, -1));

        jLabel2.setText("Book  ID");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(93, 68, 57, -1));

        jLabel3.setText("Student ID");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(93, 108, -1, -1));

        jButton1.setText("Done");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(234, 158, -1, -1));

        jButton2.setText("Cancel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(93, 158, -1, -1));
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(234, 65, 71, -1));
        getContentPane().add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(234, 105, 71, -1));

        jPanel1.setBackground(new java.awt.Color(87, 166, 161));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 440, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 340, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 440, 340));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        String s_id, book_id;

        if (jTextField1.getText().isEmpty() || jTextField2.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please fill in all the fields.");
        } else {

            book_id = jTextField1.getText();
            s_id = jTextField2.getText();

            int std_id = Integer.parseInt(s_id);
            int b_id = Integer.parseInt(book_id);
//
            try {
                Connection con = ConnectionProvider.getCon();
                Statement st = con.createStatement();
                   Statement st2 = con.createStatement();
                      Statement st3 = con.createStatement();
                       Statement st5 = con.createStatement();
                        Statement st6 = con.createStatement();
                ResultSet rs = st.executeQuery(" SELECT Book_Name FROM booklist where Book_ID ='" + b_id + "';");
           ResultSet rs5 = st5.executeQuery(" SELECT Book_Name FROM booklist where Quantitiy >0 and Book_ID ='" + b_id + "';");
           
                
                ResultSet rs2 = st2.executeQuery(" SELECT S_name FROM member where S_Id ='" + std_id + "';");
                if (!rs.next()) {
                    JOptionPane.showMessageDialog(null, "Book not available ");
                    return;
                }
                if (!rs2.next()) {
                    JOptionPane.showMessageDialog(null, "Member not available ");
                    return;
                }

                
                
                 if (!rs5.next()) {
                    JOptionPane.showMessageDialog(null, "Insufficient book ");
                    return;
                }
                
              st6.executeUpdate("INSERT INTO issue_backup (Book_name, Book_Id, Issued_By, Return_Date) " +
                  "SELECT b.Book_name, b.Book_Id, m.S_name, NULL " +
                  "FROM booklist AS b " +
                  "JOIN member AS m ON m.S_Id = " + std_id + " AND b.Book_Id = " + b_id);

                
                
//                  st6.executeUpdate("INSERT INTO issue_backup (Book_name, Book_Id, Issued_By,Return_Date) " + "SELECT b.Book_name, b.Book_Id, m.S_name " + "FROM booklist as b "
//                        + "JOIN member as m ON m.S_Id = " + std_id + " AND b.Book_ID = " + b_id);
                
                
                st.executeUpdate("INSERT INTO issue (Book_name, Book_Id, Issued_By) " + "SELECT b.Book_name, b.Book_Id, m.S_name " + "FROM booklist as b "
                        + "JOIN member as m ON m.S_Id = " + std_id + " AND b.Book_ID = " + b_id);

                
                  st3.executeUpdate("UPDATE booklist SET Quantitiy = Quantitiy + " + (-1) + " where Book_ID ='" + b_id + "';");
          
                JOptionPane.showMessageDialog(null, "Issued successfully!");
                setVisible(false);

            } catch (Exception e) {

                // e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error occurred: " + e.getMessage());
            }
        }

        //
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new IssueBook().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}
